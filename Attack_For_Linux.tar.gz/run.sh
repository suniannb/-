sudo apt install nodejs nmap
chmod +777 ./super_attack
mv -f ./super_attack /bin
echo "安装成功,您可以使用super_attack来进行网站攻击"

